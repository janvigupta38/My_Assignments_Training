package com.janvi;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

// HanderInterceptorAdapter is deprecated
public class InterceptorClass implements HandlerInterceptor{

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		// TODO Auto-generated method stub
		Calendar cal=Calendar.getInstance();
		int dayOfWeek=cal.get(cal.HOUR_OF_DAY);
		if(dayOfWeek>=12 && dayOfWeek<=1) { // 1 is for Sunday
			response.getWriter().write("The Website is closed for Maintaince. Please try on other days of week");
			return false;
		}
		return true;
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		System.out.println("HandlerInterceptor : SPring MVC called afterCompletion method for "+request.getRequestURI().toString());
		
	
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		System.out.println("HandlerInterceptor : SPring MVC called postHandle method for "+request.getRequestURI().toString());
		
		
	}
	
	
	
}
