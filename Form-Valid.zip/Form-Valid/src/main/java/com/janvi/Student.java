package com.janvi;
import java.util.List;

import javax.validation.constraints.Max;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.Date;
@JsonInclude(JsonInclude.Include.NON_NULL)
//@JsonIgnoreProperties({"studentHobby"})
@JsonPropertyOrder({"student_name","studentMobile","studentDOB","studentHobby","studentSkills","studentaddress"})
public class Student {
	@JsonProperty("student_name")
	@Pattern(regexp="[^0-9]*") //no digits should be there
	private String studentName;
	@Size(min=2,max=10) @IsValidHobby(listofHobbies="Music|FootBall|Cricket|Hockey") 
	// by default {0} is the field name and (1)= max and (2)=min , it is according  to alphabetical order in properties file
	private String studentHobby;
	@Max(2222) //<=2222
	private Long studentMobile;
	@Past //Past date
	private Date studentDOB;
	private List<String> studentSkills;
	private Address studentaddress;

	public Address getStudentaddress() {
		return studentaddress;
	}
	public void setStudentaddress(Address studentaddress) {
		this.studentaddress = studentaddress;
	}
	public Long getStudentMobile() {
		return studentMobile;
	}
	public void setStudentMobile(Long studentMobile) {
		this.studentMobile = studentMobile;
	}
	public Date getStudentDOB() {
		return studentDOB;
	}
	public void setStudentDOB(Date studentDOB) {
		this.studentDOB = studentDOB;
	}
	public List<String> getStudentSkills() {
		return studentSkills;
	}
	public void setStudentSkills(List<String> studentSkills) {
		this.studentSkills = studentSkills;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentHobby() {
		return studentHobby;
	}
	public void setStudentHobby(String studentHobby) {
		this.studentHobby = studentHobby;
	}
	

}
