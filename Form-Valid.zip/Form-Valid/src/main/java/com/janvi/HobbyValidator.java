package com.janvi;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class HobbyValidator implements ConstraintValidator<IsValidHobby, String>{
	private String listofHobbies;
	public void initialize(IsValidHobby isValidHobby) {
		this.listofHobbies=isValidHobby.listofHobbies();
	}
	@Override
	public boolean isValid(String studentHobby, ConstraintValidatorContext context) {
		// TODO Auto-generated method stub
		if(studentHobby == null)
		return false;
		if(studentHobby.matches(listofHobbies))
		return true;
		else
		return false;
	}
	

}
