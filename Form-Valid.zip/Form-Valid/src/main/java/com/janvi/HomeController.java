package com.janvi;

import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

// RequestParam
//	@RequestMapping(value="/submitadmissionform.html",method=RequestMethod.POST)
//	public ModelAndView submitAdmissionForm(@RequestParam(value="studentName", defaultValue="User123") String name,@RequestParam("studentHobby") String hobby{
//			Student st1=new Student();
//			st1.setStudentName(name);
//			st1.setCity(hobby);
//			
//	ModelAndView model = new ModelAndView("AdmissionSuccess");
//	model.addObject("headerMessage","GLA University, India");
//	model.addObject("st1",st1);

//	return model;
//}

	@InitBinder //if we want some specific way for fields we can use this
	public void initBinder(WebDataBinder binder) {
		// binder.setDisallowedFields(new String[] {"studentMobile"}); 
		// this will not show mobile value in submitted html page as we have metion it as setDisallowedFields
		SimpleDateFormat dateFromat = new SimpleDateFormat("yyyy***MM***dd");
		binder.registerCustomEditor(Date.class, "studentDOB", new CustomDateEditor(dateFromat, false));
		//if we want date in a specific format
		binder.registerCustomEditor(String.class, "studentName", new StudentNameEditor());
		//Name with Mr or Ms as prefix
	}

	@ModelAttribute //Do all the work done by RequestParam and student object above
	public void addCommonObjects(Model model) {
		model.addAttribute("msg", "GLA University");
	}

	@RequestMapping(value = "/admissionform.html", method = RequestMethod.GET)
	public ModelAndView getAdmissionForm() throws Exception {

		String exception="ARITHMETIC_EXCEPTION";
		if(exception.contentEquals("NULL_POINTER")) {
			throw new NullPointerException("Null Pointer Exception");
		}else if(exception.contentEquals("ARITHMETIC_EXCEPTION")) {
			throw new ArithmeticException("Arithmetic Exception");
		}else if(exception.contentEquals("IO_EXCEPTION")) {
			throw new IOException("IO Exception");
		}
		ModelAndView model = new ModelAndView("AdmissionForm");
//		model.addObject("msg", "Gla University");
		return model;

	}

	
	@RequestMapping(value = "/submitadmission.html", method = RequestMethod.POST)
	public ModelAndView SubmitAdmissionForm(@Valid @ModelAttribute("student1") Student student1, BindingResult result) {
		if (result.hasErrors()) {
			ModelAndView model = new ModelAndView("AdmissionForm");
//			model.addObject("msg", "Gla University");
			return model;
		}

		ModelAndView model = new ModelAndView("AdmissionSuccess");

		return model;

	}
	
	
}
