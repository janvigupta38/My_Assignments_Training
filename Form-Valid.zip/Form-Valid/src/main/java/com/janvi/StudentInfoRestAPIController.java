package com.janvi;


import java.util.ArrayList;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
public class StudentInfoRestAPIController {
	// for all students
//		@ResponseBody
		@RequestMapping(value="/students",method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
		public ArrayList<Student> getStudentList(){
			Student student1=new Student();
			student1.setStudentName("janvi gupta");
			
			Student student3=new Student();
			student3.setStudentName("manu gupta");
			
			Student student2=new Student();
			student2.setStudentName("amit gupta");
			
			ArrayList<Student> studentsList=new ArrayList<Student>();
			
			studentsList.add(student1);
			studentsList.add(student2);
			studentsList.add(student3);
			return studentsList;
		}
		
		
		//for specific student
//		@ResponseBody
		@RequestMapping(value="/students/{name}",method=RequestMethod.GET)
		public Student getStudent(@PathVariable("name") String studentName){
			Student student1=new Student();
			student1.setStudentName(studentName);
			student1.setStudentHobby("Singing");
			
			
			
			
			return student1;
		}
		
}
